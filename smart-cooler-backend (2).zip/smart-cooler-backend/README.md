# Smart Water Cooler Backend

A backend for an IoT smart water cooler, focused on **predictive maintenance**
and **water quality monitoring**. Built with FastAPI + SQLAlchemy.

## Features

- **Device registry** — register and manage multiple smart cooler units
- **Telemetry ingestion** — devices push sensor readings (TDS, pH, turbidity,
  water temp, compressor current/vibration, filter pressure drop, flow rate,
  compressor runtime)
- **Water quality monitoring** — every incoming reading is automatically
  checked against safe drinking water thresholds (TDS, pH, turbidity); breaches
  generate `warning` or `critical` alerts
- **Predictive maintenance** — a transparent, rule-based scoring engine
  computes a 0.0–1.0 risk score per device from compressor current/vibration,
  filter clogging (pressure drop), filter age, and compressor runtime, plus
  trend detection (e.g. rising vibration over recent readings). Generates
  alerts and an overall status: `healthy` / `monitor` / `service_soon` / `service_now`
- **Maintenance logs** — record service history (e.g. filter replacements
  automatically reset the filter-age clock)
- **Dashboard endpoint** — single call returns device status, latest readings,
  water quality status, and maintenance risk for a unit

## Quick start

```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open **http://127.0.0.1:8000/docs** for interactive Swagger API docs where you
can try every endpoint directly in the browser.

By default this uses a local SQLite file (`smart_cooler.db`) — zero setup
required. For production, set the `DATABASE_URL` environment variable to a
Postgres connection string:

```bash
export DATABASE_URL="postgresql://user:password@host:5432/smart_cooler"
```

## API overview

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/devices` | Register a new cooler |
| GET | `/devices` | List all coolers |
| GET | `/devices/{id}` | Get one cooler |
| POST | `/devices/{id}/telemetry` | Submit a sensor reading (triggers alert checks) |
| GET | `/devices/{id}/telemetry` | Get recent telemetry history |
| GET | `/devices/{id}/water-alerts` | List water quality alerts |
| POST | `/water-alerts/{id}/resolve` | Mark a water alert resolved |
| GET | `/devices/{id}/maintenance-alerts` | List predictive maintenance alerts |
| POST | `/maintenance-alerts/{id}/resolve` | Mark a maintenance alert resolved |
| POST | `/devices/{id}/maintenance-logs` | Log a real service event |
| GET | `/devices/{id}/maintenance-logs` | View service history |
| GET | `/devices/{id}/dashboard` | Combined status summary for a cooler |

## Example: simulating a device

```bash
# Register a cooler
curl -X POST http://127.0.0.1:8000/devices \
  -H "Content-Type: application/json" \
  -d '{"serial_number":"SC-001","name":"Lobby Cooler","location":"HQ Lobby"}'

# Push a sensor reading
curl -X POST http://127.0.0.1:8000/devices/1/telemetry \
  -H "Content-Type: application/json" \
  -d '{"tds_ppm":180,"ph_level":7.1,"turbidity_ntu":0.4,"compressor_current_a":3.2,"compressor_vibration_mm_s":1.5,"filter_pressure_drop_kpa":8,"compressor_runtime_hours":1200}'

# Check the dashboard
curl http://127.0.0.1:8000/devices/1/dashboard
```

## Tuning thresholds

- Water quality safe ranges: `app/water_quality.py` → `SAFE_RANGES`
- Predictive maintenance baselines: `app/predictive_maintenance.py` → `BASELINES`

Calibrate these against your cooler's actual spec sheet and observed healthy-unit
telemetry for best accuracy.

## Upgrading to a trained ML model

`compute_risk_score()` in `app/predictive_maintenance.py` is currently rule-based
so it works without any training data. Once you've collected enough historical
telemetry + failure labels, you can replace its body with a call to a trained
model (e.g. `scikit-learn` classifier loaded via `pickle`/`joblib`) that takes
the same `features` dict and returns a risk score — no other code needs to change.

## Project structure

```
app/
  main.py                   # FastAPI routes
  models.py                 # SQLAlchemy ORM models
  schemas.py                 # Pydantic request/response schemas
  database.py                # DB engine/session setup
  water_quality.py           # Water quality threshold logic
  predictive_maintenance.py  # Risk scoring engine
requirements.txt
```
