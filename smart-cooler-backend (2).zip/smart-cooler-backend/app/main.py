"""
Smart Water Cooler Backend
Predictive maintenance + water quality monitoring API.

Run locally:
    pip install -r requirements.txt
    uvicorn app.main:app --reload

Then open http://127.0.0.1:8000/docs for interactive API docs.
"""
from datetime import datetime
from typing import List, Optional

from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import desc

from . import models, schemas
from .database import engine, get_db, Base
from .water_quality import evaluate_water_quality, overall_water_status
from .predictive_maintenance import compute_risk_score

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Smart Water Cooler API",
    description="Predictive maintenance and water quality monitoring for IoT smart water coolers.",
    version="1.0.0",
)


# ---------------------------------------------------------------------------
# Devices
# ---------------------------------------------------------------------------

@app.post("/devices", response_model=schemas.DeviceOut, tags=["Devices"])
def register_device(payload: schemas.DeviceCreate, db: Session = Depends(get_db)):
    existing = db.query(models.Device).filter_by(serial_number=payload.serial_number).first()
    if existing:
        raise HTTPException(status_code=400, detail="A device with this serial number already exists.")
    device = models.Device(**payload.model_dump())
    db.add(device)
    db.commit()
    db.refresh(device)
    return device


@app.get("/devices", response_model=List[schemas.DeviceOut], tags=["Devices"])
def list_devices(db: Session = Depends(get_db)):
    return db.query(models.Device).all()


@app.get("/devices/{device_id}", response_model=schemas.DeviceOut, tags=["Devices"])
def get_device(device_id: int, db: Session = Depends(get_db)):
    device = db.query(models.Device).get(device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found.")
    return device


# ---------------------------------------------------------------------------
# Telemetry ingestion
# ---------------------------------------------------------------------------

@app.post("/devices/{device_id}/telemetry", response_model=schemas.TelemetryOut, tags=["Telemetry"])
def ingest_telemetry(device_id: int, payload: schemas.TelemetryIn, db: Session = Depends(get_db)):
    """
    Devices call this endpoint on each reporting interval (e.g. every 5 minutes)
    to push sensor readings. This automatically runs water quality checks and
    predictive maintenance scoring, generating alerts as needed.
    """
    device = db.query(models.Device).get(device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found.")

    reading = models.Telemetry(device_id=device_id, **payload.model_dump())
    db.add(reading)
    db.commit()
    db.refresh(reading)

    # --- Water quality evaluation ---
    issues = evaluate_water_quality(payload.model_dump())
    for parameter, value, severity, message in issues:
        db.add(models.WaterQualityAlert(
            device_id=device_id, telemetry_id=reading.id,
            parameter=parameter, value=value, severity=severity, message=message,
        ))

    # --- Predictive maintenance evaluation ---
    recent = (
        db.query(models.Telemetry)
        .filter_by(device_id=device_id)
        .order_by(desc(models.Telemetry.timestamp))
        .limit(10)
        .all()
    )
    recent_dicts = [
        {
            "compressor_current_a": r.compressor_current_a,
            "compressor_vibration_mm_s": r.compressor_vibration_mm_s,
        }
        for r in reversed(recent)
    ]
    filter_age_days = (datetime.utcnow() - device.filter_installed_at).days

    result = compute_risk_score(payload.model_dump(), recent_dicts, filter_age_days)
    for component, score, severity, message in result["alerts"]:
        db.add(models.MaintenanceAlert(
            device_id=device_id, component=component,
            risk_score=score, severity=severity, message=message,
        ))

    db.commit()
    return reading


@app.get("/devices/{device_id}/telemetry", response_model=List[schemas.TelemetryOut], tags=["Telemetry"])
def get_telemetry_history(device_id: int, limit: int = 100, db: Session = Depends(get_db)):
    return (
        db.query(models.Telemetry)
        .filter_by(device_id=device_id)
        .order_by(desc(models.Telemetry.timestamp))
        .limit(limit)
        .all()
    )


# ---------------------------------------------------------------------------
# Water quality alerts
# ---------------------------------------------------------------------------

@app.get("/devices/{device_id}/water-alerts", response_model=List[schemas.WaterQualityAlertOut], tags=["Water Quality"])
def get_water_alerts(device_id: int, only_open: bool = True, db: Session = Depends(get_db)):
    q = db.query(models.WaterQualityAlert).filter_by(device_id=device_id)
    if only_open:
        q = q.filter_by(resolved=False)
    return q.order_by(desc(models.WaterQualityAlert.created_at)).all()


@app.post("/water-alerts/{alert_id}/resolve", tags=["Water Quality"])
def resolve_water_alert(alert_id: int, db: Session = Depends(get_db)):
    alert = db.query(models.WaterQualityAlert).get(alert_id)
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found.")
    alert.resolved = True
    db.commit()
    return {"status": "resolved", "alert_id": alert_id}


# ---------------------------------------------------------------------------
# Predictive maintenance alerts
# ---------------------------------------------------------------------------

@app.get("/devices/{device_id}/maintenance-alerts", response_model=List[schemas.MaintenanceAlertOut], tags=["Maintenance"])
def get_maintenance_alerts(device_id: int, only_open: bool = True, db: Session = Depends(get_db)):
    q = db.query(models.MaintenanceAlert).filter_by(device_id=device_id)
    if only_open:
        q = q.filter_by(resolved=False)
    return q.order_by(desc(models.MaintenanceAlert.created_at)).all()


@app.post("/maintenance-alerts/{alert_id}/resolve", tags=["Maintenance"])
def resolve_maintenance_alert(alert_id: int, db: Session = Depends(get_db)):
    alert = db.query(models.MaintenanceAlert).get(alert_id)
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found.")
    alert.resolved = True
    db.commit()
    return {"status": "resolved", "alert_id": alert_id}


@app.post("/devices/{device_id}/maintenance-logs", response_model=schemas.MaintenanceLogOut, tags=["Maintenance"])
def log_maintenance(device_id: int, payload: schemas.MaintenanceLogCreate, db: Session = Depends(get_db)):
    device = db.query(models.Device).get(device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found.")

    log = models.MaintenanceLog(device_id=device_id, **payload.model_dump())
    db.add(log)

    # If a filter was replaced, reset the filter installation date
    if payload.action.lower() in ("filter_replacement", "filter_change"):
        device.filter_installed_at = datetime.utcnow()

    db.commit()
    db.refresh(log)
    return log


@app.get("/devices/{device_id}/maintenance-logs", response_model=List[schemas.MaintenanceLogOut], tags=["Maintenance"])
def get_maintenance_logs(device_id: int, db: Session = Depends(get_db)):
    return (
        db.query(models.MaintenanceLog)
        .filter_by(device_id=device_id)
        .order_by(desc(models.MaintenanceLog.performed_at))
        .all()
    )


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------

@app.get("/devices/{device_id}/dashboard", response_model=schemas.DeviceDashboard, tags=["Dashboard"])
def device_dashboard(device_id: int, db: Session = Depends(get_db)):
    device = db.query(models.Device).get(device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found.")

    latest = (
        db.query(models.Telemetry)
        .filter_by(device_id=device_id)
        .order_by(desc(models.Telemetry.timestamp))
        .first()
    )

    water_status = "good"
    if latest:
        latest_dict = {
            "tds_ppm": latest.tds_ppm, "ph_level": latest.ph_level, "turbidity_ntu": latest.turbidity_ntu,
        }
        issues = evaluate_water_quality(latest_dict)
        water_status = overall_water_status(issues)

    recent = (
        db.query(models.Telemetry)
        .filter_by(device_id=device_id)
        .order_by(desc(models.Telemetry.timestamp))
        .limit(10)
        .all()
    )
    recent_dicts = [
        {
            "compressor_current_a": r.compressor_current_a,
            "compressor_vibration_mm_s": r.compressor_vibration_mm_s,
        }
        for r in reversed(recent)
    ]
    filter_age_days = (datetime.utcnow() - device.filter_installed_at).days
    risk_result = compute_risk_score(
        latest.__dict__ if latest else {}, recent_dicts, filter_age_days
    )

    open_water = db.query(models.WaterQualityAlert).filter_by(device_id=device_id, resolved=False).count()
    open_maint = db.query(models.MaintenanceAlert).filter_by(device_id=device_id, resolved=False).count()

    return schemas.DeviceDashboard(
        device=device,
        latest_telemetry=latest,
        water_quality_status=water_status,
        maintenance_risk_score=risk_result["risk_score"],
        maintenance_status=risk_result["status"],
        open_water_alerts=open_water,
        open_maintenance_alerts=open_maint,
        filter_age_days=filter_age_days,
    )


@app.get("/", tags=["Health"])
def health_check():
    return {"status": "ok", "service": "Smart Water Cooler API"}
