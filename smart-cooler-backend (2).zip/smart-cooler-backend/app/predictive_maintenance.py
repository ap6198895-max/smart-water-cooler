"""
Predictive maintenance engine.

This uses a transparent, rule-based scoring model (weighted thresholds +
trend detection) so it works immediately with no training data. It's
structured so you can later swap `compute_risk_score()` for a trained
ML model (e.g. a scikit-learn classifier/regressor) without changing
any calling code — just replace the function body to call model.predict()
on the same `features` dict.

Risk score is 0.0 (healthy) to 1.0 (imminent failure).
"""
from datetime import datetime
from typing import List, Optional

# Reference "healthy" baselines — calibrate these from your device spec sheet
# or from observed healthy-unit telemetry.
BASELINES = {
    "compressor_current_a": {"normal_max": 4.5, "fail_threshold": 7.0},
    "compressor_vibration_mm_s": {"normal_max": 2.8, "fail_threshold": 4.5},
    "filter_pressure_drop_kpa": {"normal_max": 15.0, "fail_threshold": 35.0},
    "filter_lifespan_days": 90,           # recommend replacement cadence
    "compressor_service_hours": 8000,     # recommended service interval
}


def _normalize(value: float, normal_max: float, fail_threshold: float) -> float:
    """Map a raw sensor value to a 0..1 risk contribution."""
    if value is None:
        return 0.0
    if value <= normal_max:
        return 0.0
    if value >= fail_threshold:
        return 1.0
    return (value - normal_max) / (fail_threshold - normal_max)


def compute_risk_score(
    latest: dict,
    recent_history: Optional[List[dict]] = None,
    filter_age_days: int = 0,
) -> dict:
    """
    Compute a predictive maintenance risk assessment.

    latest: most recent telemetry reading (dict of sensor values)
    recent_history: list of recent readings (oldest->newest) for trend detection
    filter_age_days: days since filter was installed

    Returns dict: {
        "risk_score": float 0..1,
        "component_scores": {component: score},
        "status": "healthy"|"monitor"|"service_soon"|"service_now",
        "alerts": [(component, score, severity, message), ...]
    }
    """
    recent_history = recent_history or []
    component_scores = {}
    alerts = []

    # --- Compressor current ---
    current = latest.get("compressor_current_a")
    cfg = BASELINES["compressor_current_a"]
    score = _normalize(current, cfg["normal_max"], cfg["fail_threshold"])
    component_scores["compressor_current"] = score

    # --- Compressor vibration ---
    vibration = latest.get("compressor_vibration_mm_s")
    cfg = BASELINES["compressor_vibration_mm_s"]
    score = _normalize(vibration, cfg["normal_max"], cfg["fail_threshold"])
    component_scores["compressor_vibration"] = score

    # --- Filter pressure drop (indicates clogging) ---
    pressure_drop = latest.get("filter_pressure_drop_kpa")
    cfg = BASELINES["filter_pressure_drop_kpa"]
    score = _normalize(pressure_drop, cfg["normal_max"], cfg["fail_threshold"])
    component_scores["filter_clogging"] = score

    # --- Filter age ---
    filter_score = min(filter_age_days / BASELINES["filter_lifespan_days"], 1.0) if filter_age_days else 0.0
    component_scores["filter_age"] = filter_score

    # --- Compressor cumulative runtime ---
    runtime = latest.get("compressor_runtime_hours")
    runtime_score = 0.0
    if runtime:
        runtime_score = min(runtime / BASELINES["compressor_service_hours"], 1.0)
    component_scores["compressor_runtime"] = runtime_score

    # --- Trend detection: is vibration or current rising over recent history? ---
    trend_bonus = 0.0
    if len(recent_history) >= 3:
        vib_values = [r.get("compressor_vibration_mm_s") for r in recent_history if r.get("compressor_vibration_mm_s") is not None]
        if len(vib_values) >= 3 and vib_values[-1] > vib_values[0] * 1.15:
            trend_bonus = 0.15
            alerts.append((
                "compressor", trend_bonus, "medium",
                "Compressor vibration shows a rising trend over recent readings — early sign of wear."
            ))

    # --- Aggregate weighted risk score ---
    weights = {
        "compressor_current": 0.25,
        "compressor_vibration": 0.25,
        "filter_clogging": 0.20,
        "filter_age": 0.10,
        "compressor_runtime": 0.10,
    }
    base_score = sum(component_scores[k] * w for k, w in weights.items())
    risk_score = min(base_score + trend_bonus, 1.0)

    # --- Component-level alerts ---
    if component_scores["compressor_current"] >= 0.6 or component_scores["compressor_vibration"] >= 0.6:
        sev = "high" if max(component_scores["compressor_current"], component_scores["compressor_vibration"]) >= 0.85 else "medium"
        alerts.append((
            "compressor", max(component_scores["compressor_current"], component_scores["compressor_vibration"]), sev,
            "Compressor readings indicate elevated mechanical stress. Inspection recommended."
        ))
    if component_scores["filter_clogging"] >= 0.5 or component_scores["filter_age"] >= 0.9:
        sev = "high" if component_scores["filter_clogging"] >= 0.8 or filter_age_days > BASELINES["filter_lifespan_days"] else "medium"
        alerts.append((
            "filter", max(component_scores["filter_clogging"], component_scores["filter_age"]), sev,
            f"Filter shows signs of clogging or has exceeded recommended lifespan ({filter_age_days} days). Replacement recommended."
        ))

    # --- Overall status ---
    if risk_score >= 0.75:
        status = "service_now"
    elif risk_score >= 0.45:
        status = "service_soon"
    elif risk_score >= 0.2:
        status = "monitor"
    else:
        status = "healthy"

    return {
        "risk_score": round(risk_score, 3),
        "component_scores": {k: round(v, 3) for k, v in component_scores.items()},
        "status": status,
        "alerts": alerts,
    }
