from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, ConfigDict


# ---------- Device ----------

class DeviceCreate(BaseModel):
    serial_number: str
    name: str
    location: Optional[str] = None
    model: Optional[str] = None


class DeviceOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    serial_number: str
    name: str
    location: Optional[str]
    model: Optional[str]
    installed_at: datetime
    filter_installed_at: datetime
    is_active: bool


# ---------- Telemetry ----------

class TelemetryIn(BaseModel):
    """Payload a device sends on each reporting interval. All sensor fields optional
    since not every device/tick will report every sensor."""
    tds_ppm: Optional[float] = None
    ph_level: Optional[float] = None
    turbidity_ntu: Optional[float] = None
    water_temp_c: Optional[float] = None
    compressor_current_a: Optional[float] = None
    compressor_vibration_mm_s: Optional[float] = None
    ambient_temp_c: Optional[float] = None
    flow_rate_lpm: Optional[float] = None
    filter_pressure_drop_kpa: Optional[float] = None
    compressor_runtime_hours: Optional[float] = None


class TelemetryOut(TelemetryIn):
    model_config = ConfigDict(from_attributes=True)
    id: int
    device_id: int
    timestamp: datetime


# ---------- Alerts ----------

class WaterQualityAlertOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    device_id: int
    created_at: datetime
    parameter: str
    value: float
    severity: str
    message: str
    resolved: bool


class MaintenanceAlertOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    device_id: int
    created_at: datetime
    component: str
    risk_score: float
    severity: str
    message: str
    resolved: bool


# ---------- Maintenance log ----------

class MaintenanceLogCreate(BaseModel):
    action: str
    notes: Optional[str] = None
    technician: Optional[str] = None


class MaintenanceLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    device_id: int
    performed_at: datetime
    action: str
    notes: Optional[str]
    technician: Optional[str]


# ---------- Dashboard ----------

class DeviceDashboard(BaseModel):
    device: DeviceOut
    latest_telemetry: Optional[TelemetryOut]
    water_quality_status: str          # "good" | "warning" | "critical"
    maintenance_risk_score: float
    maintenance_status: str            # "healthy" | "monitor" | "service_soon" | "service_now"
    open_water_alerts: int
    open_maintenance_alerts: int
    filter_age_days: int
