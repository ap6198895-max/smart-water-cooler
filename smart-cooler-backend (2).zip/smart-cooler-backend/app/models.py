"""
ORM models for the smart water cooler system.

Entities:
- Device: a physical smart water cooler unit
- Telemetry: time-series sensor readings sent by a device
- WaterQualityAlert: generated when a reading breaches safe thresholds
- MaintenanceAlert: generated when predictive maintenance flags risk
- MaintenanceLog: record of actual service/maintenance performed
"""
from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Float, DateTime, ForeignKey, Boolean, Text
)
from sqlalchemy.orm import relationship
from .database import Base


class Device(Base):
    __tablename__ = "devices"

    id = Column(Integer, primary_key=True, index=True)
    serial_number = Column(String, unique=True, index=True, nullable=False)
    name = Column(String, nullable=False)
    location = Column(String, nullable=True)
    model = Column(String, nullable=True)
    installed_at = Column(DateTime, default=datetime.utcnow)
    filter_installed_at = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Boolean, default=True)

    telemetry = relationship("Telemetry", back_populates="device", cascade="all, delete-orphan")
    water_alerts = relationship("WaterQualityAlert", back_populates="device", cascade="all, delete-orphan")
    maintenance_alerts = relationship("MaintenanceAlert", back_populates="device", cascade="all, delete-orphan")
    maintenance_logs = relationship("MaintenanceLog", back_populates="device", cascade="all, delete-orphan")


class Telemetry(Base):
    __tablename__ = "telemetry"

    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(Integer, ForeignKey("devices.id"), nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)

    # Water quality sensors
    tds_ppm = Column(Float, nullable=True)          # Total Dissolved Solids
    ph_level = Column(Float, nullable=True)
    turbidity_ntu = Column(Float, nullable=True)
    water_temp_c = Column(Float, nullable=True)

    # Mechanical / electrical sensors (predictive maintenance signals)
    compressor_current_a = Column(Float, nullable=True)
    compressor_vibration_mm_s = Column(Float, nullable=True)
    ambient_temp_c = Column(Float, nullable=True)
    flow_rate_lpm = Column(Float, nullable=True)
    filter_pressure_drop_kpa = Column(Float, nullable=True)
    compressor_runtime_hours = Column(Float, nullable=True)  # cumulative

    device = relationship("Device", back_populates="telemetry")


class WaterQualityAlert(Base):
    __tablename__ = "water_quality_alerts"

    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(Integer, ForeignKey("devices.id"), nullable=False)
    telemetry_id = Column(Integer, ForeignKey("telemetry.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    parameter = Column(String, nullable=False)   # e.g. "tds_ppm"
    value = Column(Float, nullable=False)
    severity = Column(String, nullable=False)    # "warning" | "critical"
    message = Column(Text, nullable=False)
    resolved = Column(Boolean, default=False)

    device = relationship("Device", back_populates="water_alerts")


class MaintenanceAlert(Base):
    __tablename__ = "maintenance_alerts"

    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(Integer, ForeignKey("devices.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    component = Column(String, nullable=False)   # "compressor" | "filter" | "general"
    risk_score = Column(Float, nullable=False)    # 0.0 - 1.0
    severity = Column(String, nullable=False)     # "low" | "medium" | "high"
    message = Column(Text, nullable=False)
    resolved = Column(Boolean, default=False)

    device = relationship("Device", back_populates="maintenance_alerts")


class MaintenanceLog(Base):
    __tablename__ = "maintenance_logs"

    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(Integer, ForeignKey("devices.id"), nullable=False)
    performed_at = Column(DateTime, default=datetime.utcnow)
    action = Column(String, nullable=False)   # e.g. "filter_replacement", "compressor_service"
    notes = Column(Text, nullable=True)
    technician = Column(String, nullable=True)

    device = relationship("Device", back_populates="maintenance_logs")
