"""
Water quality monitoring logic.

Thresholds are based on common drinking water guidelines (WHO / BIS 10500 style
ranges for TDS, pH, turbidity). Adjust SAFE_RANGES to match your region's
regulations or your specific cooler's spec sheet.
"""
from typing import List, Tuple

# (parameter, min_warning, min_critical, max_warning, max_critical)
# A value is "critical" if it crosses the critical bound, "warning" if it
# crosses the warning bound but not the critical one.
SAFE_RANGES = {
    "tds_ppm":        {"min": None, "max_warning": 500,  "max_critical": 1000},
    "ph_level":       {"min_warning": 6.5, "min_critical": 6.0,
                        "max_warning": 8.5, "max_critical": 9.5},
    "turbidity_ntu":  {"min": None, "max_warning": 1.0,  "max_critical": 5.0},
}


def evaluate_water_quality(reading: dict) -> List[Tuple[str, float, str, str]]:
    """
    Given a dict of sensor readings, return a list of
    (parameter, value, severity, message) tuples for any breaches found.
    severity is "warning" or "critical".
    """
    issues = []

    tds = reading.get("tds_ppm")
    if tds is not None:
        cfg = SAFE_RANGES["tds_ppm"]
        if tds >= cfg["max_critical"]:
            issues.append(("tds_ppm", tds, "critical",
                            f"TDS reading of {tds} ppm far exceeds safe drinking limits (>{cfg['max_critical']} ppm). Water may be unsafe to drink."))
        elif tds >= cfg["max_warning"]:
            issues.append(("tds_ppm", tds, "warning",
                            f"TDS reading of {tds} ppm is above the recommended limit ({cfg['max_warning']} ppm). Consider filter inspection."))

    ph = reading.get("ph_level")
    if ph is not None:
        cfg = SAFE_RANGES["ph_level"]
        if ph <= cfg["min_critical"] or ph >= cfg["max_critical"]:
            issues.append(("ph_level", ph, "critical",
                            f"pH level of {ph} is critically outside the safe range ({cfg['min_critical']}-{cfg['max_critical']})."))
        elif ph <= cfg["min_warning"] or ph >= cfg["max_warning"]:
            issues.append(("ph_level", ph, "warning",
                            f"pH level of {ph} is outside the ideal range ({cfg['min_warning']}-{cfg['max_warning']})."))

    turb = reading.get("turbidity_ntu")
    if turb is not None:
        cfg = SAFE_RANGES["turbidity_ntu"]
        if turb >= cfg["max_critical"]:
            issues.append(("turbidity_ntu", turb, "critical",
                            f"Turbidity of {turb} NTU is critically high (>{cfg['max_critical']} NTU). Water clarity is unsafe."))
        elif turb >= cfg["max_warning"]:
            issues.append(("turbidity_ntu", turb, "warning",
                            f"Turbidity of {turb} NTU exceeds the recommended limit ({cfg['max_warning']} NTU)."))

    return issues


def overall_water_status(issues: List[Tuple[str, float, str, str]]) -> str:
    if any(i[2] == "critical" for i in issues):
        return "critical"
    if any(i[2] == "warning" for i in issues):
        return "warning"
    return "good"
